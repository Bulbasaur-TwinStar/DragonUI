local addon = select(2, ...);

--[[
================================================================================
DragonUI - Core Initialization
================================================================================
This file handles the main addon initialization using AceAddon-3.0.
Utility functions have been moved to core/api.lua

Options are loaded on demand from DragonUI_Options addon (ElvUI pattern).
================================================================================
]]

-- Expose addon globally for DragonUI_Options to access
_G.DragonUI = addon

-- Localization (initialized early in config.lua so core/ files can use it)
local L = addon.L

-- Create addon object using AceAddon
addon.core = LibStub("AceAddon-3.0"):NewAddon("DragonUI", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0");

-- Pre-define Options table (will be filled by DragonUI_Options)
addon.Options = { type = "group", name = "DragonUI", args = {} }

-- Track if options addon is loaded
addon.OptionsLoaded = false

function addon.core:OnInitialize()
    -- Replace the temporary addon.db with the real AceDB
    addon.db = LibStub("AceDB-3.0"):New("DragonUIMoPDB", addon.defaults);

    -- First point where the stored language override is readable; UI is built later (PLAYER_LOGIN).
    addon.RefreshLocale()

    addon:ApplyDatabaseMigrations()

    -- Force defaults to be written to profile (check for specific key that should always exist)
    if not addon.db.profile.mainbars or not addon.db.profile.mainbars.scale_actionbar then
        -- Copy all defaults to profile to ensure they exist in SavedVariables
        addon.DeepCopy(addon.defaults.profile, addon.db.profile);
        addon:ApplyDatabaseMigrations()
    end

    -- Register callbacks for configuration changes
    addon.db.RegisterCallback(addon, "OnProfileChanged", "RefreshConfig");
    addon.db.RegisterCallback(addon, "OnProfileCopied", "RefreshConfig");
    addon.db.RegisterCallback(addon, "OnProfileReset", "RefreshConfig");

    -- Apply current profile configuration immediately
    -- This ensures the profile is loaded when the addon starts
    addon:RefreshConfig();
end

function addon.core:OnEnable()
    -- Register slash commands (using new commands.lua system)
    if addon.LoadCommands then
        addon.LoadCommands()
    else
        -- Fallback to legacy registration
        self:RegisterChatCommand("dragonui", "SlashCommand")
        self:RegisterChatCommand("dui", "SlashCommand")
    end

    -- Fire custom event to signal that DragonUI is fully initialized
    -- This ensures modules get the correct config values
    self:SendMessage("DRAGONUI_READY");
end

-- ============================================================================
-- OPTIONS UI LOADING (ElvUI Pattern)
-- ============================================================================

function addon:ToggleOptionsUI(msg)
    if InCombatLockdown() then
        addon:Error(L["Cannot open options in combat."])
        return
    end

    if not IsAddOnLoaded("DragonUI_Options") then
        local noConfig
        local reason = select(6, GetAddOnInfo("DragonUI_Options"))
        
        if reason ~= "MISSING" and reason ~= "DISABLED" then
            LoadAddOn("DragonUI_Options")
            
            -- Check if it actually loaded
            if not IsAddOnLoaded("DragonUI_Options") then 
                noConfig = true 
            else
                addon.OptionsLoaded = true
            end
        else
            noConfig = true
        end

        if noConfig then
            addon:Error(L["Error -- Addon 'DragonUI_Options' not found or is disabled."])
            return
        end
    end

    -- Use the custom panel
    if addon.OptionsPanel then
        addon.OptionsPanel:Toggle(msg)
    else
        addon:Error(L["Options panel not available. Try /reload."])
    end
end

-- Callback function that refreshes all modules when configuration changes
function addon:RefreshConfig()
    -- Also runs on profile switch: the newly-activated profile may be older than the current schema.
    addon:ApplyDatabaseMigrations()

    -- Initialize cooldown system if it hasn't been already
    if addon.InitializeCooldowns then
        addon.InitializeCooldowns()
    end

    local failed = addon:RefreshRegisteredSystems() or {}

    -- If some configurations failed, retry them after 2 seconds
    if #failed > 0 then
        addon.core:ScheduleTimer(function()
            addon:RefreshRegisteredSystems()
        end, 2);
    end
end

-- Legacy SlashCommand handler (fallback if commands.lua not loaded)
function addon.core:SlashCommand(input)
    -- Delegate to new command system if available
    if addon.CommandHandlers then
        if not input or input:trim() == "" then
            addon:ToggleOptionsUI()
        elseif input:lower() == "config" then
            addon:ToggleOptionsUI()
        elseif input:lower() == "edit" or input:lower() == "editor" then
            addon.CommandHandlers.ToggleEditorMode()
        elseif input:lower() == "help" then
            addon.CommandHandlers.ShowHelp()
        else
            addon.CommandHandlers.ShowHelp()
        end
    else
        -- Original fallback
        if not input or input:trim() == "" then
            addon:ToggleOptionsUI()
        elseif input:lower() == "config" then
            addon:ToggleOptionsUI()
        elseif input:lower() == "edit" or input:lower() == "editor" then
            if addon.EditorMode then
                addon.EditorMode:Toggle()
            else
                addon:Error(L["Editor mode not available."])
            end
        else
            addon:Print(L["Commands: /dragonui config, /dragonui edit"])
        end
    end
end


-- =============================================================================
-- MAX CAMERA ZOOM (50 yards, same as ElvUI / Leatrix Plus in MoP 5.4.8)
-- =============================================================================
do
    local cf = CreateFrame("Frame")
    cf:RegisterEvent("PLAYER_ENTERING_WORLD")
    cf:SetScript("OnEvent", function()
        SetCVar("cameraDistanceMax", 50)
        SetCVar("cameraDistanceMaxFactor", 3.4)
    end)
end

-- DragonUI Combo Points Bar under PlayerFrame (Event-driven via GetComboPoints API)
do
    local cpBar = CreateFrame("Frame", "DragonUIComboBar", UIParent)
    cpBar:SetSize(102, 13)
    cpBar:SetFrameStrata("DIALOG")
    cpBar:SetFrameLevel(30)
    cpBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 8, edgeSize = 8,
        insets = { left = 2, right = 2, top = 2, bottom = 2 }
    })
    cpBar:SetBackdropColor(0.06, 0.06, 0.06, 0.92)
    cpBar:SetBackdropBorderColor(0.62, 0.50, 0.28, 1)
    cpBar:Hide()

    local dots = {}
    for i = 1, 5 do
        local f = CreateFrame("Frame", nil, cpBar)
        f:SetSize(18, 7)
        local bg = f:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetTexture("Interface\\Buttons\\WHITE8X8")
        bg:SetVertexColor(0.14, 0.14, 0.14, 0.85)
        local fill = f:CreateTexture(nil, "ARTWORK")
        fill:SetAllPoints()
        fill:SetTexture("Interface\\TargetingFrame\\UI-StatusBar")
        fill:Hide()
        f.fill = fill
        dots[i] = f
    end

    local function UpdateComboBar()
        local _, pClass = UnitClass("player")
        if pClass ~= "ROGUE" and pClass ~= "DRUID" then cpBar:Hide(); return end
        if not UnitExists("target") or UnitIsDead("target") then cpBar:Hide(); return end
        local pts = GetComboPoints("player", "target") or 0
        if pts <= 0 then cpBar:Hide(); return end

        local anchor = _G.PlayerFrameHealthBar or _G.PlayerFrame
        if anchor then
            local hasAltMana = (pClass == "DRUID") and ((_G.DruidManaBar and _G.DruidManaBar:IsShown()) or (_G.PlayerFrameAlternateManaBar and _G.PlayerFrameAlternateManaBar:IsShown()) or (UnitPowerType("player") ~= 0 and UnitPowerMax("player", 0) > 0))
            local targetW = hasAltMana and 102 or 118
            cpBar:SetWidth(targetW)
            local pad, gap = 3, 1.5
            local dotW = ((targetW - (pad * 2)) - (gap * 4)) / 5
            for i = 1, 5 do
                dots[i]:SetSize(dotW, 7)
                dots[i]:ClearAllPoints()
                dots[i]:SetPoint("LEFT", cpBar, "LEFT", pad + (i - 1) * (dotW + gap), 0)
            end
            cpBar:ClearAllPoints()
            local isFat = _G.DragonUI and _G.DragonUI.db and _G.DragonUI.db.profile and _G.DragonUI.db.profile.unitframe and _G.DragonUI.db.profile.unitframe.player and _G.DragonUI.db.profile.unitframe.player.fat_healthbar
            local yOff = (hasAltMana and -26 or -17) - (isFat and 6 or 0)
            cpBar:SetPoint("TOP", anchor, "BOTTOM", hasAltMana and 4 or 0, yOff)
        end

        for i = 1, 5 do
            if i <= pts then
                if i == 5 then dots[i].fill:SetVertexColor(0.95, 0.18, 0.12, 1)
                elseif i >= 3 then dots[i].fill:SetVertexColor(1.0, 0.50, 0.08, 1)
                else dots[i].fill:SetVertexColor(1.0, 0.85, 0.12, 1) end
                dots[i].fill:Show()
            else
                dots[i].fill:Hide()
            end
        end
        cpBar:Show()
    end

    local cpEvents = CreateFrame("Frame")
    cpEvents:RegisterEvent("PLAYER_ENTERING_WORLD")
    cpEvents:RegisterEvent("PLAYER_TARGET_CHANGED")
    cpEvents:RegisterEvent("UNIT_COMBO_POINTS")
    cpEvents:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
    cpEvents:SetScript("OnEvent", function(_, event, unit)
        if event == "UNIT_COMBO_POINTS" and unit ~= "player" and unit ~= "vehicle" then return end
        UpdateComboBar()
    end)
end

-- 1:1 Authentic BalancePowerTracker-style Eclipse Bar integrated into DragonUI
do
    local bpt = CreateFrame("Frame", "DragonUIBalanceBar", UIParent)
    bpt:SetSize(110, 18)
    bpt:SetFrameStrata("MEDIUM")
    bpt:SetFrameLevel(20)
    bpt:Hide()

    local function MakeIconBox(parent, size)
        local f = CreateFrame("Frame", nil, parent)
        f:SetSize(size, size)
        f:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = false, tileSize = 0, edgeSize = 9,
            insets = { left = 2, right = 2, top = 2, bottom = 2 }
        })
        f:SetBackdropColor(0.05, 0.05, 0.06, 0.95)
        f:SetBackdropBorderColor(0.75, 0.72, 0.66, 1)
        return f
    end

    local moonBox = MakeIconBox(bpt, 18)
    moonBox:SetPoint("LEFT", bpt, "LEFT", 0, 0)
    local moonTex = moonBox:CreateTexture(nil, "ARTWORK")
    moonTex:SetPoint("TOPLEFT", 2, -2)
    moonTex:SetPoint("BOTTOMRIGHT", -2, 2)
    moonTex:SetTexture("Interface\\Icons\\Ability_Druid_Eclipse")
    moonTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local moonGlow1 = moonBox:CreateTexture(nil, "OVERLAY")
    moonGlow1:SetSize(32, 32)
    moonGlow1:SetPoint("CENTER", moonBox, "CENTER", 0, 0)
    moonGlow1:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    moonGlow1:SetBlendMode("ADD")
    moonGlow1:SetVertexColor(1.0, 0.92, 0.65, 1)
    moonGlow1:Hide()

    local moonGlow2 = moonBox:CreateTexture(nil, "OVERLAY")
    moonGlow2:SetSize(30, 30)
    moonGlow2:SetPoint("CENTER", moonBox, "CENTER", 0, 0)
    moonGlow2:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    moonGlow2:SetBlendMode("ADD")
    moonGlow2:SetVertexColor(1.0, 0.96, 0.82, 0.9)
    moonGlow2:Hide()

    local sunBox = MakeIconBox(bpt, 18)
    sunBox:SetPoint("RIGHT", bpt, "RIGHT", 0, 0)
    local sunTex = sunBox:CreateTexture(nil, "ARTWORK")
    sunTex:SetPoint("TOPLEFT", 2, -2)
    sunTex:SetPoint("BOTTOMRIGHT", -2, 2)
    sunTex:SetTexture("Interface\\Icons\\Ability_Druid_EclipseOrange")
    sunTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local sunGlow1 = sunBox:CreateTexture(nil, "OVERLAY")
    sunGlow1:SetSize(32, 32)
    sunGlow1:SetPoint("CENTER", sunBox, "CENTER", 0, 0)
    sunGlow1:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    sunGlow1:SetBlendMode("ADD")
    sunGlow1:SetVertexColor(1.0, 0.92, 0.65, 1)
    sunGlow1:Hide()

    local sunGlow2 = sunBox:CreateTexture(nil, "OVERLAY")
    sunGlow2:SetSize(30, 30)
    sunGlow2:SetPoint("CENTER", sunBox, "CENTER", 0, 0)
    sunGlow2:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    sunGlow2:SetBlendMode("ADD")
    sunGlow2:SetVertexColor(1.0, 0.96, 0.82, 0.9)
    sunGlow2:Hide()

    local midBar = CreateFrame("Frame", nil, bpt)
    midBar:SetHeight(13)
    midBar:SetPoint("LEFT", moonBox, "RIGHT", 2, 0)
    midBar:SetPoint("RIGHT", sunBox, "LEFT", -2, 0)
    midBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = false, tileSize = 0, edgeSize = 10,
        insets = { left = 2, right = 2, top = 2, bottom = 2 }
    })
    midBar:SetBackdropColor(0.05, 0.05, 0.06, 0.95)
    midBar:SetBackdropBorderColor(0.75, 0.72, 0.66, 1)

    local lunarBg = midBar:CreateTexture(nil, "ARTWORK")
    lunarBg:SetPoint("TOPLEFT", midBar, "TOPLEFT", 2, -2)
    lunarBg:SetPoint("BOTTOMRIGHT", midBar, "BOTTOM", 0, 2)
    lunarBg:SetTexture("Interface\\TargetingFrame\\UI-StatusBar")
    lunarBg:SetTexCoord(1, 0, 0, 1)
    lunarBg:SetVertexColor(0.06, 0.30, 0.86, 0.98)

    local solarBg = midBar:CreateTexture(nil, "ARTWORK")
    solarBg:SetPoint("TOPLEFT", midBar, "TOP", 0, -2)
    solarBg:SetPoint("BOTTOMRIGHT", midBar, "BOTTOMRIGHT", -2, 2)
    solarBg:SetTexture("Interface\\TargetingFrame\\UI-StatusBar")
    solarBg:SetVertexColor(0.88, 0.48, 0.04, 0.98)

    local gainBar = midBar:CreateTexture(nil, "ARTWORK", nil, 2)
    gainBar:SetHeight(9)
    gainBar:SetTexture("Interface\\TargetingFrame\\UI-StatusBar")
    gainBar:SetBlendMode("ADD")
    gainBar:Hide()

    local arrow = midBar:CreateTexture(nil, "OVERLAY")
    arrow:SetSize(12, 12)
    arrow:SetTexture("Interface\\PlayerFrame\\UI-DruidEclipse")
    arrow:SetBlendMode("ADD")
    arrow:SetTexCoord(0.922, 1.0, 0.82, 1.0)
    arrow:SetPoint("CENTER", midBar, "CENTER", 0, 0)

    local valText = midBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    valText:SetPoint("CENTER", midBar, "CENTER", 0, 0.5)
    valText:SetFont(STANDARD_TEXT_FONT, 9, "OUTLINE")
    valText:SetText("0")

    local WRATH_NAME = GetSpellInfo(5176) or "Wrath"
    local STARFIRE_NAME = GetSpellInfo(2912) or "Starfire"
    local STARSURGE_NAME = GetSpellInfo(78674) or "Starsurge"

    local function UpdateBalanceTracker()
        if (IsAddOnLoaded and IsAddOnLoaded("BalancePowerTracker")) or _G.BalancePowerTracker or _G.BPT_Frame then
            bpt:Hide()
            return
        end

        local _, pClass = UnitClass("player")
        local spec = GetSpecialization and GetSpecialization()
        local form = GetShapeshiftFormID and GetShapeshiftFormID()
        if pClass ~= "DRUID" or spec ~= 1 or form == 1 or form == 4 or form == 5 or form == 8 or form == 27 or form == 29 then
            bpt:Hide()
            return
        end

        local eb = _G.EclipseBarFrame
        if eb then
            eb:SetAlpha(0)
            eb:EnableMouse(false)
            if eb.powerText then eb.powerText:SetAlpha(0); eb.powerText:Hide() end
        end

        local anchor = _G.PlayerFrameHealthBar or _G.PlayerFrame
        if anchor then
            local targetW = (anchor:GetWidth() or 119) - 9
            if targetW < 80 then targetW = 110 end
            bpt:SetWidth(targetW)
            local isFat = _G.DragonUI and _G.DragonUI.db and _G.DragonUI.db.profile and _G.DragonUI.db.profile.unitframe and _G.DragonUI.db.profile.unitframe.player and _G.DragonUI.db.profile.unitframe.player.fat_healthbar
            bpt:ClearAllPoints()
            bpt:SetPoint("TOP", anchor, "BOTTOM", 5, isFat and -25 or -19)
        end

        local power = UnitPower("player", 8) or 0
        local maxPower = UnitPowerMax("player", 8) or 100
        if maxPower <= 0 then maxPower = 100 end
        valText:SetText(tostring(math.abs(power)))

        local halfW = math.max(4, (midBar:GetWidth() - 4) / 2)
        local normEnergy = math.max(-1, math.min(1, power / maxPower))

        arrow:ClearAllPoints()
        arrow:SetPoint("CENTER", midBar, "CENTER", normEnergy * (halfW - 2), 0)
        local dir = GetEclipseDirection and GetEclipseDirection()
        if dir == "moon" then arrow:SetTexCoord(1.0, 0.914, 0.641, 0.82)
        elseif dir == "sun" then arrow:SetTexCoord(0.914, 1.0, 0.641, 0.82)
        else arrow:SetTexCoord(0.922, 1.0, 0.82, 1.0) end

        local casting = UnitCastingInfo("player")
        local delta = 0
        if casting == WRATH_NAME then delta = -15
        elseif casting == STARFIRE_NAME then delta = 20
        elseif casting == STARSURGE_NAME then delta = (dir == "moon") and -20 or 20 end

        if delta ~= 0 then
            local predEnergy = math.max(-100, math.min(100, power + delta))
            local pFrom = normEnergy * halfW
            local pTo = (predEnergy / maxPower) * halfW
            local segW = math.abs(pTo - pFrom)
            if segW >= 1 then
                gainBar:ClearAllPoints()
                if pTo > pFrom then
                    gainBar:SetPoint("LEFT", midBar, "CENTER", pFrom, 0)
                    gainBar:SetVertexColor(1.0, 0.82, 0.25, 0.65)
                else
                    gainBar:SetPoint("RIGHT", midBar, "CENTER", pFrom, 0)
                    gainBar:SetVertexColor(0.35, 0.78, 1.0, 0.65)
                end
                gainBar:SetWidth(segW)
                gainBar:Show()
            else gainBar:Hide() end
        else gainBar:Hide() end

        local hasLunar = UnitBuff("player", GetSpellInfo(48518) or "Eclipse (Lunar)")
        local hasSolar = UnitBuff("player", GetSpellInfo(48517) or "Eclipse (Solar)")

        if hasLunar then
            moonBox:SetBackdropBorderColor(1.0, 0.95, 0.78, 1); moonGlow1:Show(); moonGlow2:Show()
            sunBox:SetBackdropBorderColor(0.45, 0.43, 0.40, 0.9); sunGlow1:Hide(); sunGlow2:Hide()
        elseif hasSolar then
            sunBox:SetBackdropBorderColor(1.0, 0.95, 0.78, 1); sunGlow1:Show(); sunGlow2:Show()
            moonBox:SetBackdropBorderColor(0.45, 0.43, 0.40, 0.9); moonGlow1:Hide(); moonGlow2:Hide()
        else
            moonBox:SetBackdropBorderColor(0.75, 0.72, 0.66, 1); sunBox:SetBackdropBorderColor(0.75, 0.72, 0.66, 1)
            moonGlow1:Hide(); moonGlow2:Hide(); sunGlow1:Hide(); sunGlow2:Hide()
        end
        bpt:Show()
    end

    local ef = CreateFrame("Frame")
    ef:RegisterEvent("PLAYER_ENTERING_WORLD")
    ef:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
    ef:RegisterEvent("PLAYER_TALENT_UPDATE")
    ef:RegisterEvent("UNIT_POWER_FREQUENT")
    ef:RegisterEvent("UNIT_POWER")
    ef:RegisterEvent("UNIT_AURA")
    ef:RegisterEvent("ECLIPSE_DIRECTION_CHANGE")
    ef:RegisterEvent("UNIT_SPELLCAST_START")
    ef:RegisterEvent("UNIT_SPELLCAST_STOP")
    ef:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
    ef:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
    ef:SetScript("OnEvent", function(_, event, unit)
        if unit and unit ~= "player" then return end
        UpdateBalanceTracker()
    end)
end

-- Anchor PaladinPowerBar cleanly below DragonUI PlayerFrame (with Fat Healthbar support)
do
    local function AlignPaladinBar()
        local p = _G.PaladinPowerBar
        local anchor = _G.PlayerFrameHealthBar or _G.PlayerFrame
        if not p or not anchor or InCombatLockdown() then return end
        local isFat = _G.DragonUI and _G.DragonUI.db and _G.DragonUI.db.profile and _G.DragonUI.db.profile.unitframe and _G.DragonUI.db.profile.unitframe.player and _G.DragonUI.db.profile.unitframe.player.fat_healthbar
        p:ClearAllPoints()
        p:SetPoint("TOP", anchor, "BOTTOM", 0, isFat and -21 or -15)
    end

    local pf = CreateFrame("Frame")
    pf:RegisterEvent("PLAYER_ENTERING_WORLD")
    pf:RegisterEvent("PLAYER_LEVEL_UP")
    pf:RegisterEvent("PLAYER_TALENT_UPDATE")
    pf:SetScript("OnEvent", AlignPaladinBar)

    if _G.PaladinPowerBar then
        hooksecurefunc(_G.PaladinPowerBar, "SetPoint", function(self)
            if self._dragonAligning then return end
            self._dragonAligning = true
            AlignPaladinBar()
            self._dragonAligning = nil
        end)
    end
end

-- Extend quest progress / error text visibility duration (7 seconds)
if UIErrorsFrame and UIErrorsFrame.SetTimeVisible then
    UIErrorsFrame:SetTimeVisible(7)
end
